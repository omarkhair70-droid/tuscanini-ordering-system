import { readdirSync, readFileSync, existsSync, mkdirSync, copyFileSync, statSync } from 'node:fs';
import { resolve, join } from 'node:path';
const target=resolve(process.argv[2]??process.cwd());
const from=resolve(import.meta.dirname,'public/images/rebirth/generated');
const to=join(target,'public/images/rebirth/generated');
if(!existsSync(join(target,'components/rebirth/product-artwork.tsx'))){
 console.error('This is not Tuscanini Next.js repository root:',target);
 process.exit(1);
}
const names=Array.from({length:100},(_,i)=>'b'+String(1+Math.floor(i/10)).padStart(2,'0')+'-'+String(i%10+1).padStart(2,'0')+'.webp');
for (const name of names){
 const original=join(from,name);
 if(!existsSync(original))throw Error('Image missing from import package: '+original);
 const bytes=readFileSync(original);
 if(bytes.length<20000||bytes.subarray(0,4).toString()!=='RIFF'||bytes.subarray(8,12).toString()!=='WEBP')throw Error('Not a valid WebP: '+name);
}
mkdirSync(to,{recursive:true});
for(const name of names)copyFileSync(join(from,name),join(to,name));
console.log('100/100 optimized AI illustrative food images copied to '+to);
console.log('Optional local preview: set NEXT_PUBLIC_REBIRTH_GENERATED_IMAGES=ready in .env.local, then npm run dev');
console.log('Before committing, run NEXT_PUBLIC_REBIRTH_GENERATED_IMAGES=ready node scripts/qa/verify-generated-menu-media.mjs');
console.log('No deploy or git push was done. These are AI illustrative references, not real named restaurant dish photos.');
