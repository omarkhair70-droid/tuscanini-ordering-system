# TUSCANINI PASS 19 — 100 AI Illustrative Menu Images

100 locally optimized WebP card assets, **NOT** verified photos from the restaurant.
Copy the entire `public/images/rebirth/generated` directory into the `omarkhair70-droid/tuscanini-ordering-system` repository root on branch `redesign/tuscanini-authored-experience-20261018`. Do not delete originals in ChatGPT Library.
All 100 image entries are catalogued in `generated-food-inventory.json`. `B07` collage-derived pizza assets are padded to squares instead of cropping pizza itself, with original aspect retained as provenance.
**This ZIP is an asset-delivery package; producing it does not mean its bytes are already committed to GitHub.** All proposed SKU matches are illustrative family/ingredient approximations only, not proof of actual ingredients or offer contents.

For a clean build run `npm ci && npx tsc --noEmit && npm run build && node scripts/qa/rebirth-interaction-check.mjs`. Do not merge PR #59 or deploy to production without the owner's explicit approval.

## تثبيت سريع داخل نسخة المشروع
1. فك ضغط الملف إلى مجلد عمل.
2. من أي مكان: `node install-images.mjs /path/to/tuscanini-ordering-system`.
3. السكربت ينسخ 100 ملف WebP لمسار `public/images/rebirth/generated/` بعد التحقق من صحة الملفات، ولا يغيّر الأسعار أو قواعد البيانات ولا يدمج أو ينشر.
4. لمعاينة الصور محليًا فقط أضف `NEXT_PUBLIC_REBIRTH_GENERATED_IMAGES=ready` إلى `.env.local`، ثم `npm run dev`.
5. شغّل `NEXT_PUBLIC_REBIRTH_GENERATED_IMAGES=ready node scripts/qa/verify-generated-menu-media.mjs` بعد نسخ الملفات. راجع الصور وأكّد موافقة المالك قبل تفعيل المتغير في أي بيئة نشر.
